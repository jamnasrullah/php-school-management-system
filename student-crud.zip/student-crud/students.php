<?php
include ('database.php');
$subjects = $conn->query("SELECT * FROM subjects");
?>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- jQuery + Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<div class="container mt-4">
    <h2>Students</h2>
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addStudentModal">
        Add Student
    </button>
    <div id="studentTable"></div>
</div>

<!-- Add Student Modal -->
<div class="modal fade" id="addStudentModal" tabindex="-1" aria-labelledby="addStudentModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="addStudentForm">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addStudentModalLabel">Add Student</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <input type="text" name="name" class="form-control mb-3" placeholder="Student Name" required>
          <select name="subject_id" class="form-select" required>
            <option value="" disabled selected>Select Subject</option>
            <?php while ($row = $subjects->fetch_assoc()): ?>
              <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Save</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>
<!-- Edit Student Modal -->
<div class="modal fade" id="editStudentModal" tabindex="-1">
  <div class="modal-dialog">
    <form id="editStudentForm">
      <input type="hidden" name="id" id="editStudentId">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Edit Student</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="text" name="name" id="editStudentName" class="form-control mb-2" required>
          <select name="subject_id" id="editStudentSubject" class="form-select" required>
            <?php
            $subjects->data_seek(0); // reset pointer
            while ($row = $subjects->fetch_assoc()):
            ?>
              <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="modal-footer">
          <button class="btn btn-primary" type="submit">Update</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
function loadStudents() {
    $.get("ajax/student_list.php", function(data) {
        $("#studentTable").html(data);
    });
}

$("#addStudentForm").on("submit", function(e) {
    e.preventDefault();
    $.post("ajax/student_add.php", $(this).serialize(), function(response) {
        if (response.trim() === "success") {
            $("#addStudentModal").modal('hide');
            loadStudents();
            $("#addStudentForm")[0].reset();
        } else {
            alert("Error: " + response);
        }
    }).fail(function(xhr) {
        alert("AJAX Error: " + xhr.responseText);
    });
});

$(document).on("click", ".deleteBtn", function() {
    const id = $(this).data("id");
    if (confirm("Are you sure?")) {
        $.post("ajax/student_delete.php", { id }, function(response) {
            loadStudents();
        });
    }
});

loadStudents();
// Open student edit modal
$(document).on("click", ".editStudent", function() {
    const id = $(this).data("id");
    $.get("ajax/student_get.php", { id }, function(res) {
        const data = JSON.parse(res);
        $("#editStudentId").val(data.id);
        $("#editStudentName").val(data.name);
        $("#editStudentSubject").val(data.subject_id);
        $("#editStudentModal").modal("show");
    });
});

// Submit student edit form
$("#editStudentForm").on("submit", function(e) {
    e.preventDefault();
    $.post("ajax/student_update.php", $(this).serialize(), function(resp) {
        if (resp.trim() === "success") {
            $("#editStudentModal").modal("hide");
            loadStudents();
        } else alert("Error: " + resp);
    });
});

</script>
