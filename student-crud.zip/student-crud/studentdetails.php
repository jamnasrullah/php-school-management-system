<?php
include ('database.php');

$sql = "SELECT students.name AS student, subjects.name AS subject, teachers.name AS teacher
        FROM students
        LEFT JOIN subjects ON students.subject_id = subjects.id
        LEFT JOIN teachers ON subjects.teacher_id = teachers.id";

$result = $conn->query($sql);
?>

<!-- Bootstrap CSS (Only include if not already loaded in parent layout) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="container mt-4">
    <h2 class="mb-4 text-center">Student Details</h2>

    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Student</th>
                    <th>Subject</th>
                    <th>Teacher</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['student']) ?></td>
                    <td><?= htmlspecialchars($row['subject']) ?></td>
                    <td><?= htmlspecialchars($row['teacher']) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
