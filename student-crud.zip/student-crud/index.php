<!DOCTYPE html>
<html>
<head>
    <title>School Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- jQuery + Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body { font-family: Arial, sans-serif; }
        iframe { width: 100%; height: calc(100vh - 112px); border: none; }
        .navbar-nav .nav-link { color: white !important; }
        .navbar { background-color: #343a40; }
        .navbar-brand { color: #fff !important; font-weight: bold; }
    </style>
</head>
<body>

<!-- Header and Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">School Management</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="students.php" target="content">Students</a></li>
        <li class="nav-item"><a class="nav-link" href="teachers.php" target="content">Teachers</a></li>
        <li class="nav-item"><a class="nav-link" href="subjects.php" target="content">Subjects</a></li>
        <li class="nav-item"><a class="nav-link" href="studentdetails.php" target="content">Student Details</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Content Area -->
<iframe name="content" src="students.php"></iframe>

</body>
</html>
