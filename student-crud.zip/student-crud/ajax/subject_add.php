<?php
include ('database.php');

$name = trim($_POST['name']);
$teacher_id = intval($_POST['teacher_id']);

if ($name && $teacher_id) {
    $stmt = $conn->prepare("INSERT INTO subjects (name, teacher_id) VALUES (?, ?)");
    $stmt->bind_param("si", $name, $teacher_id);
    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "DB Error";
    }
} else {
    echo "Missing name or teacher";
}
