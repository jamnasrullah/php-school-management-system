<?php
include ('database.php');
$id = intval($_POST['id']);
$name = trim($_POST['name']);
$subject_id = intval($_POST['subject_id']);

if ($name && $subject_id) {
    $stmt = $conn->prepare("UPDATE students SET name = ?, subject_id = ? WHERE id = ?");
    $stmt->bind_param("sii", $name, $subject_id, $id);
    echo $stmt->execute() ? "success" : "DB error";
} else echo "Invalid input";
