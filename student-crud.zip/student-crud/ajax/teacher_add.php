<?php
include ('database.php');
$name = $_POST['name'];
$conn->query("INSERT INTO teachers (name) VALUES ('$name')");
