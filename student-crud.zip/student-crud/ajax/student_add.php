<?php
include ('database.php');
$name = trim($_POST['name']);
$subject_id = intval($_POST['subject_id']);

if ($name && $subject_id) {
    $stmt = $conn->prepare("INSERT INTO students (name, subject_id) VALUES (?, ?)");
    $stmt->bind_param("si", $name, $subject_id);
    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "DB Error";
    }
} else {
    echo "Invalid Input";
}
