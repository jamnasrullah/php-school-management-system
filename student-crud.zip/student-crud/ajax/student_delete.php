<?php
include ('database.php');
$id = intval($_POST['id']);
$conn->query("DELETE FROM students WHERE id = $id");
