<?php
include ('database.php');
$result = $conn->query("SELECT * FROM teachers");
?>

<table class="table table-bordered">
  <thead>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= $row['id'] ?></td>
      <td><?= htmlspecialchars($row['name']) ?></td>
      <td>
        <button class="btn btn-sm btn-warning editTeacher"
                data-id="<?= $row['id'] ?>"
                data-name="<?= htmlspecialchars($row['name']) ?>">
          Edit
        </button>
        <button class="btn btn-sm btn-danger deleteTeacher" data-id="<?= $row['id'] ?>">
          Delete
        </button>
      </td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>
