<?php
include ('database.php');
$id = intval($_GET['id']);
$res = $conn->query("SELECT * FROM subjects WHERE id = $id");
echo json_encode($res->fetch_assoc());
