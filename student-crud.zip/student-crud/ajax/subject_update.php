<?php
include ('database.php');
$id = intval($_POST['id']);
$name = trim($_POST['name']);
$teacher_id = intval($_POST['teacher_id']);

if ($name && $teacher_id && $id) {
    $stmt = $conn->prepare("UPDATE subjects SET name = ?, teacher_id = ? WHERE id = ?");
    $stmt->bind_param("sii", $name, $teacher_id, $id);
    echo $stmt->execute() ? "success" : "DB error";
} else {
    echo "Invalid input";
}
