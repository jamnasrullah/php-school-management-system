<?php
include ('database.php');

$sql = "SELECT subjects.id, subjects.name AS subject, teachers.name AS teacher 
        FROM subjects 
        LEFT JOIN teachers ON subjects.teacher_id = teachers.id";
$result = $conn->query($sql);
?>

<table class="table table-bordered">
  <thead>
    <tr><th>ID</th><th>Subject</th><th>Teacher</th><th>Action</th></tr>
  </thead>
  <tbody>
    <?php while ($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['subject'] ?></td>
        <td><?= $row['teacher'] ?></td>
       <td>
  <button class="btn btn-sm btn-warning editSubject"
          data-id="<?= $row['id'] ?>"
          data-name="<?= htmlspecialchars($row['subject']) ?>"
          data-teacher="<?= $row['teacher'] ?>">
      Edit
  </button>
  <button class="btn btn-sm btn-danger deleteSubject" data-id="<?= $row['id'] ?>">Delete</button>
</td>

      </tr>
    <?php endwhile; ?>
  </tbody>
</table>
