<?php
include ('database.php');
$id = $_POST['id'];
$conn->query("DELETE FROM teachers WHERE id = $id");
