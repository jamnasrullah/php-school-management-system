<?php
include ('database.php');
$id = intval($_POST['id']);
$name = trim($_POST['name']);

if ($name && $id) {
    $stmt = $conn->prepare("UPDATE teachers SET name = ? WHERE id = ?");
    $stmt->bind_param("si", $name, $id);
    echo $stmt->execute() ? "success" : "DB error";
} else {
    echo "Invalid input";
}
