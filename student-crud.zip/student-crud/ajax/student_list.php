<?php
include ('database.php');

// Fetch students with their subject names
$sql = "SELECT students.id, students.name, students.subject_id, subjects.name AS subject_name 
        FROM students 
        LEFT JOIN subjects ON students.subject_id = subjects.id";
$result = $conn->query($sql);
?>

<!-- Student List Table -->
<table class="table table-bordered">
  <thead>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Subject</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= $row['id'] ?></td>
      <td><?= htmlspecialchars($row['name']) ?></td>
      <td><?= htmlspecialchars($row['subject_name']) ?></td>
      <td>
        <button class="btn btn-sm btn-warning editStudent"
                data-id="<?= $row['id'] ?>"
                data-name="<?= htmlspecialchars($row['name']) ?>"
                data-subject="<?= $row['subject_id'] ?>">
          Edit
        </button>
        <button class="btn btn-sm btn-danger deleteBtn" data-id="<?= $row['id'] ?>">Delete</button>
      </td>
    </tr>
    <?php endwhile; ?>
  </tbody>
</table>
