<?php
include ('database.php');
$teachers = $conn->query("SELECT * FROM teachers");
?>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- jQuery and Bootstrap Bundle JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<div class="container mt-4">
    <h2>Subjects</h2>
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addSubjectModal">Add Subject</button>
    <div id="subjectTable"></div>
</div>

<!-- Add Subject Modal -->
<div class="modal fade" id="addSubjectModal" tabindex="-1" aria-labelledby="addSubjectModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="addSubjectForm">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addSubjectModalLabel">Add Subject</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <input type="text" name="name" class="form-control mb-3" placeholder="Subject Name" required>
          <select name="teacher_id" class="form-select" required>
            <option value="" disabled selected>Select Teacher</option>
            <?php while ($row = $teachers->fetch_assoc()): ?>
              <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Save</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>
<!-- Edit Model -->
 <!-- Edit Subject Modal -->
<div class="modal fade" id="editSubjectModal" tabindex="-1" aria-labelledby="editSubjectModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="editSubjectForm">
      <input type="hidden" name="id" id="editSubjectId">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Edit Subject</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <input type="text" name="name" id="editSubjectName" class="form-control mb-3" placeholder="Subject Name" required>
          <select name="teacher_id" id="editSubjectTeacher" class="form-select" required>
            <option disabled selected>Select Teacher</option>
            <?php
            $teachers->data_seek(0); // rewind
            while ($row = $teachers->fetch_assoc()):
            ?>
              <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Update</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
function loadSubjects() {
    $.get("ajax/subject_list.php", function(data) {
        $("#subjectTable").html(data);
    });
}

$("#addSubjectForm").on("submit", function(e) {
    e.preventDefault();
    $.post("ajax/subject_add.php", $(this).serialize(), function(response) {
        if (response.trim() === "success") {
            $("#addSubjectModal").modal('hide');
            $("#addSubjectForm")[0].reset();
            loadSubjects();
        } else {
            alert("Error: " + response);
        }
    }).fail(function(xhr) {
        alert("AJAX Error: " + xhr.responseText);
    });
});

$(document).on("click", ".deleteSubject", function() {
    const id = $(this).data("id");
    if (confirm("Are you sure?")) {
        $.post("ajax/subject_delete.php", { id }, function() {
            loadSubjects();
        });
    }
});

loadSubjects();
// Open modal and fill form
$(document).on("click", ".editSubject", function() {
    const id = $(this).data("id");
    const name = $(this).data("name");

    // You may need to fetch teacher_id from backend via AJAX, or store it in the data-* attribute
    $.get("ajax/subject_get.php", { id }, function(res) {
        const data = JSON.parse(res);
        $("#editSubjectId").val(data.id);
        $("#editSubjectName").val(data.name);
        $("#editSubjectTeacher").val(data.teacher_id);
        $("#editSubjectModal").modal("show");
    });
});

// Submit Edit Form
$("#editSubjectForm").on("submit", function(e) {
    e.preventDefault();
    $.post("ajax/subject_update.php", $(this).serialize(), function(response) {
        if (response.trim() === "success") {
            $("#editSubjectModal").modal("hide");
            loadSubjects();
        } else {
            alert("Update error: " + response);
        }
    });
});

</script>
