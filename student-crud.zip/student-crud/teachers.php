<?php include ('database.php');?>
<div class="container mt-4">
    <h2>Teachers</h2>
    <button class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#addTeacherModal">Add Teacher</button>
    <div id="teacherTable"></div>
</div>
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- jQuery + Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Add Teacher Modal -->
<div class="modal fade" id="addTeacherModal" tabindex="-1">
  <div class="modal-dialog">
    <form id="addTeacherForm">
      <div class="modal-content">
        <div class="modal-header"><h5 class="modal-title">Add Teacher</h5></div>
        <div class="modal-body">
          <input type="text" name="name" class="form-control" placeholder="Teacher Name" required>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Save</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>
<!-- Edit Teacher Modal -->
<div class="modal fade" id="editTeacherModal" tabindex="-1">
  <div class="modal-dialog">
    <form id="editTeacherForm">
      <input type="hidden" name="id" id="editTeacherId">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Edit Teacher</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="text" name="name" id="editTeacherName" class="form-control" required>
        </div>
        <div class="modal-footer">
          <button class="btn btn-primary" type="submit">Update</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
function loadTeachers() {
    $.get("ajax/teacher_list.php", function(data) {
        $("#teacherTable").html(data);
    });
}

$("#addTeacherForm").on("submit", function(e) {
    e.preventDefault();
    $.post("ajax/teacher_add.php", $(this).serialize(), function() {
        $("#addTeacherModal").modal('hide');
        loadTeachers();
    });
});

$(document).on("click", ".deleteTeacher", function() {
    const id = $(this).data("id");
    if (confirm("Are you sure?")) {
        $.post("ajax/teacher_delete.php", { id }, function() {
            loadTeachers();
        });
    }
});

loadTeachers();
$(document).on("click", ".editTeacher", function() {
    const id = $(this).data("id");
    $("#editTeacherId").val(id);
    $("#editTeacherName").val($(this).data("name"));
    $("#editTeacherModal").modal("show");
});

$("#editTeacherForm").on("submit", function(e) {
    e.preventDefault();
    $.post("ajax/teacher_update.php", $(this).serialize(), function(resp) {
        if (resp.trim() === "success") {
            $("#editTeacherModal").modal("hide");
            loadTeachers();
        } else alert("Error: " + resp);
    });
});

</script>
